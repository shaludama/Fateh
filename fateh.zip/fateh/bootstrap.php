<?php

use Illuminate\Database\Capsule\Manager as Capsule;

$capsule = new Capsule;
$capsule->addConnection([
    "driver"    => "mysql",
    "host"      => 'localhost',
    "database"  => 'cafegame_kalla',
    "username"  => 'cafegame_ali',
    "password"  => '8825512217',
    "charset"   => "utf8",
    "collation" => "utf8_general_ci",
    "prefix"    => ""
]);

use Illuminate\Container\Container;
$capsule->setAsGlobal();
$capsule->bootEloquent();