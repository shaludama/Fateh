<?php

namespace Library;

class Telegram {

    protected static $Token    = '464594681:AAHzHVEWm_hIUR4lzVbNpnmrEWwO48OJYow';
    protected static $url      = 'https://api.telegram.org/bot'.$this->Token;
    protected static $chatid   = Telegram::getChatId();

    
    public static function getUpdates()  { return  json_decode(file_get_contents("php://input"), JSON_UNESCAPED_UNICODE);}
    public static function getMessage()  { return $this->getUpdates()['message']['text'];             }   
    public static function getChatId()   { return $this->getUpdates()['message']['chat']['id'];       }   
    public static function getUserName() { return $this->getUpdates()['message']['chat']['username']; }
    public static function getChatDate() { return $this->getUpdates()['message']['date'];             }

    public static function exportChatInviteLink($chat_id)    {  file_get_contents(self::$url.'/exportChatInviteLink?chat_id='.self::$chat_id);                 }
    public static function setChatPhoto($chatid, $photo)     {  file_get_contents(self::$url.'/setChatPhoto?chat_id='.self::$chatid.'&photo='.$photo);         }
    public static function deleteChatPhoto($chatid)          {  file_get_contents(self::$url.'/deleteChatPhoto?chat_id='.self::$chatid);                       }
    public static function setChatTitle($chatid, $title)     {  file_get_contents(self::$url.'/setChatTitle?chat_id='.self::$chatid.'title'.$title);           }
    public static function leaveChat($chatid)                {  file_get_contents(self::$url.'/leaveChat?chat_id='.self::$chatid);                             }
    public static function getChatAdministrators($chatid)    {  file_get_contents(self::$url.'/getChatAdministrators?chat_id='.self::$chatid);                 }
    public static function getChatMembersCount($chatid)      {  file_get_contents(self::$url.'/getChatMembersCount?chat_id='.self::$chatid);                   }
    public static function getChatMember($chatid, $user_id)  {  file_get_contents(self::$url.'/getChatMember?chat_id='.self::$chatid.'&user_id='.$user_id);    } 
    public static function setChatDescription($chatid, $des) { file_get_contents(self::$url.'/setChatDescription?chat_id='.self::$chatid.'description'.$desc); } 
    public static function unpinChatMessage($chatid)         {  file_get_contents(self::$url.'/unpinChatMessage?chat_id='.self::$chatid);                      }
    public static function sendChatAction($action)           {  file_get_contents(self::$url.'/sendChatAction?chat_id='.self::$chat_id.'&action='.$action);    }
    public static function unbanChatMember($user_id)         {  file_get_contents(self::$url.'/unbanChatMember?chat_id='.self::$chat_id.'&user_id='.$user_id); }

    public static function sendMessage($message, $keyboard) { 
         

        if( isset($keyboard) ) {

            file_get_contents(self::$url."/sendmessage?chat_id=".self::$chatid."&text=".$message.'&reply_markup='.$keyboard); 

            } elseif($keyboard == false) {

            ffile_get_contents(self::$url."/sendmessage?chat_id=".self::$chatid."&text=".$message);

            }   

    } 

    public static function sendPhoto($photo_id, $photo_url, $caption, $keyboard) { 

           if( isset($keyboard) ) {

                  if( isset($photo_id) ) {
                    file_get_contents(self::$url.'/sendPhoto?chat_id='.self::$chatid.'&photo='.$photo_id.'&caption='.$caption.'&reply_markup='.$keyboard);
                } elseif ($photo_id == false) {
                    file_get_contents(self::$url.'/sendPhoto?chat_id='.self::$chatid.'&photo='.$photo_url.'&caption='.$caption.'&reply_markup='.$keyboard);
                }
             

            } elseif($keyboard == false) {
                    if( isset($photo_id) ) {
                    file_get_contents(self::$url.'/sendPhoto?chat_id='.self::$chatid.'&photo='.$photo_id.'&caption='.$caption);
                }elseif ($photo_id == false) {
                    file_get_contents(self::$url.'/sendPhoto?chat_id='.self::$chatid.'&photo='.$photo_url.'&caption='.$caption);
                }
            

            }             
        }   

        public static function sendVideo($video_id, $video_url, $caption, $keyboard) { 

           if( isset($keyboard) ) {

                  if( isset($video_id) ) {
                    file_get_contents(self::$url.'/sendVideo?chat_id='.self::$chatid.'&photo='.$video_id.'&caption='.$caption.'&reply_markup='.$keyboard);
                } elseif ($video_id == false) {
                    file_get_contents(self::$url.'/sendVideo?chat_id='.self::$chatid.'&photo='.$video_url.'&caption='.$caption.'&reply_markup='.$keyboard);
                }
             

            } elseif($keyboard == false) {
                    if( isset($video_id) ) {
                    file_get_contentsself::$url.'/sendVideo?chat_id='.self::$chatid.'&photo='.$video_id.'&caption='.$caption);
                }elseif ($video_id == false) {
                    file_get_contents(self::$url.'/sendVideo?chat_id='.self::$chatid.'&photo='.$video_url.'&caption='.$caption);
                }
            

            }             
        } 

        public static function sendDocument($doc_id, $caption, $keyboard) {
            
           
            if(isset($keyboard)) {
            file_get_contents(self::$url.'/sendDocument?chat_id='.self::$chatid.'&document='.$doc_id.'&caption='.$caption.'&reply_markup='.$keyboard); 
            } elseif($keyboard == false) {
            file_get_contents(self::$url.'/sendDocument?chat_id='.self::$chatid.'&document='.$doc_id.'&caption='.$caption);
            }                 
        } 

        public static function sendVoice($voice_id, $caption, $keyboard) {
                       
            if(isset($keyboard)) {
            file_get_contents(self::$url.'/sendVoice?chat_id='.self::$chatid.'&voice='.$voice_id.'&caption='.$caption.'&reply_markup='.$keyboard); 
            } elseif($keyboard == false) {
            file_get_contents(self::$url.'/sendVoice?chat_id='.self::$chatid.'&voice='.$voice_id.'&caption='.$caption);
            }                 
        }

        public static function sendLocation($latitude, $longitude, $live_period, $keyboard) {
            
           
            if(isset($keyboard)) {
               file_get_contents(self::$url.'/sendLocation?chat_id='.self::$chatid.'&latitude='.$latitude.'&longitude='.$longitude.'&live_period='.$live_period.'&reply_markup='.$keyboard); 
            } elseif($keyboard == false) {
               file_get_contents(self::$url.'/sendLocation?chat_id='.self::$chatid.'&latitude='.$latitude.'&longitude='.$longitude.'&live_period='.$live_period);
            }                 
        }

        public static function sendContact($phone_number, $first_name, $last_name, $keyboard) {
            
           
            if(isset($keyboard)) {
           file_get_contents(self::$url.'/sendContact?chat_id='.self::$chatid.'&phone_number='.$phone_number.'&first_name='.$first_name.'&last_name='.$last_name.'&reply_markup='.$keyboard);
            } elseif($keyboard == false) {
            file_get_contents(self::$url.'/sendContact?chat_id='.self::$chatid.'&phone_number='.$phone_number.'&first_name='.$first_name.'&last_name='.$last_name);
            }                 
        }

        public static function sendAudio($audio_id, $caption, $keyboard) {
            
           
            if(isset($keyboard)) {
            file_get_contents(self::$url.'/sendAudio?chat_id='.self::$chatid.'&audio='.$audio_id.'&caption='.$caption.'&reply_markup='.$keyboard); 
            } elseif($keyboard == false) {
            file_get_contents(self::$url.'/sendAudio?chat_id='.self::$chatid.'&audio='.$audio_id.'&caption='.$caption);
            }                 
        } 

        
        public static function forwardMessage($from_chat_id, $message_id){

            file_get_contents(self::$url.'/forwardMessage?chat_id='.self::$chatid.'&from_chat_id='.$from_chat_id.'&message_id='.$message_id);

        }


        public static function kickChatMember($user_id, $until_date){

            file_get_contents(self::$url.'/kickChatMember?chat_id='.self::$chatid.'&user_id='.$user_id.'&until_date='.$until_date);
        }

 

    


        public static function restrictChatMember($user_id, $until_date, $can_send_messages, $can_send_media_messages, $can_send_other_messages, $can_add_web_page_previews){

           file_get_contents(self::$url.'/unbanChatMember?chat_id='.self::$chatid.'&user_id='.$user_id.'&until_date='.$until_date.'&can_send_messages='.$can_send_messages.'&can_send_media_messages='.$can_send_media_messages.'&can_send_other_messages='.$can_send_other_messages.'&can_add_web_page_previews='.$can_add_web_page_previews);
        }

        public static function promoteChatMember($user_id, $can_change_info, $can_post_messages, $can_edit_messages, $can_delete_messages, $can_invite_users, $can_restrict_members, $can_pin_messages, $can_promote_members){
  
          file_get_contents(self::$url.'/unbanChatMember?chat_id='.self::$chatid.'&user_id='.$user_id.'&can_change_info='.$can_change_info.'&can_post_messages='.$can_post_messages.'&can_edit_messages='.$can_edit_messages.'&can_edit_messages='.$can_edit_messages.'&can_invite_users='.$can_invite_users.'&can_restrict_members='.$can_restrict_members.'&can_pin_messages='.$can_pin_messages.'&can_promote_members='.$can_promote_members);
        }

   


        public static function pinChatMessage($chatid, $message_id, $disable_notification){
    
         file_get_contents(self::$url.'/pinChatMessage?chat_id='.self::$chatid.'message_id'.$message_id.'&disable_notification='.$disable_notification);
        }

    }



