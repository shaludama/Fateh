<?php

namespace Library\Model;

class Tracker extends \Illuminate\Database\Eloquent\Model
{
	
}