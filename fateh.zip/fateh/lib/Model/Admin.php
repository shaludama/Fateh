<?php

namespace Library\Model;

class Admin extends \Illuminate\Database\Eloquent\Model
{
	
}